Submission of 828472 for COMP20008 2017 S1 Project Phase 3

test_wrangle 
	Contains my data wrangling functions
	3 cells in total
	Each functions processes each dataset, removing null values and standardising them into lowercase etc

test_implement
	Contains my data implementation functions
	4 cells in total
	Functions calculate the concentration values as well as match strings of the region names 
	Functions also plot the bar graph and scatter plots
	>>>There exists a problem where certain blocks of code for plotting needs to be commented out
	   before you run the code to plot the next one
	   this is explained in the comments of the first function
	   only one graph plotted at once
	
	1st cell constructs clean lists of values without zeros and plots language vs population scatterplots
	2nd cell contructs final data frame, 3rd cell plots it
	4th cell shows and plots the stats for the case study